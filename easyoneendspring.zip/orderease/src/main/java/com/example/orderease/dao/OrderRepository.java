package com.example.orderease.dao;
import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.orderease.entity.OrderEntity;

public interface OrderRepository extends JpaRepository<OrderEntity,String> {
	
	@Query(value = "SELECT * FROM orders_tab WHERE customer_id = :customerId", nativeQuery = true)
	List<OrderEntity> findByCustIdOrder(@Param("customerId") String customerId);
	
	@Query(value = "DELETE FROM orders_tab WHERE customer_id = :customerId", nativeQuery = true)
	public void deleteByCustIdOrder(@Param("customerId") String customerId);
	
	@Query(value = "SELECT * FROM orders_tab WHERE customer_id =:customerId", nativeQuery = true)
	
	List<OrderEntity> findByCustNameNative(@Param("customerId") String customerId);

}
