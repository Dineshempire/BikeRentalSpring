package com.example.orderease.dao;
import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.orderease.entity.CustomerEntity;

public interface CustomerRepository extends JpaRepository<CustomerEntity,String> {
	
	Optional<CustomerEntity> findByUserEmailOrMobileNumber(String userEmail, String mobileNumber);
	
	List<CustomerEntity> findByCustomerNameContainingIgnoreCaseOrUserEmailContainingIgnoreCase(String customerName, String userEmail);

}
