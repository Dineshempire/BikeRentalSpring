package com.example.orderease.dto;

public class ProductDto {
	
	
	private String productId;
	
	private String productName;
	
	private int productUnit;
	private int productMrp;
	private int productPrice;
	//private int productValue;
	
	private int tax;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public int getTax() {
		return tax;
	}
	public void setTax(int tax) {
		this.tax = tax;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	public int getProductUnit() {
		return productUnit;
	}
	public void setProductUnit(int productUnit) {
		this.productUnit = productUnit;
	}
	public int getProductMrp() {
		return productMrp;
	}
	
	public void setProductMrp(int productMrp) {
		this.productMrp = productMrp;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	
	
	
	
//	public int getProductValue() {
//		return productValue;
//	}
//	public void setProductValue(int productValue) {
//		this.productValue = productValue;
//	}
	public ProductDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "ProductDto [productId=" + productId + ", productName=" + productName + ", productUnit=" + productUnit
				+ ", productMrp=" + productMrp + ", productPrice=" + productPrice + ", tax=" + tax + "]";
	}
	
	
	
	
	
	
	
	
	
	
	

}
