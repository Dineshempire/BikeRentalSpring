package com.example.orderease.dao;
import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

//import com.example.orderease.dto.ResponseDto;
//import com.example.orderease.dto.ViewOrderDto;
import com.example.orderease.entity.ViewOrderEntity;

public interface ViewOrderRepository extends JpaRepository<ViewOrderEntity,String>{
	
	@Query(value = "SELECT * FROM vieworder_tab WHERE customer_id = :customerId", nativeQuery = true)
	List<ViewOrderEntity> findByCustIdNative(@Param("customerId") String customerId);
	
	@Query(value = "DELETE FROM vieworder_tab WHERE customer_id = :customerId", nativeQuery = true)
	public void deleteByCustIdNative(@Param("customerId") String customerId);
	
	
	@Query(value= "SELECT * FROM vieworder_tab WHERE order_id = :orderId", nativeQuery=true)
	List<ViewOrderEntity> findByOrderIdNative(@Param("orderId") String orderId);
	
	List<ViewOrderEntity> findByOrderId(String orderId);
	
	
    @Query(value="DELETE FROM vieworder_tab  WHERE orderId = :orderId",nativeQuery=true)
    public void deleteViewOrdersByOrderId(@Param("orderId") String orderId);

}
