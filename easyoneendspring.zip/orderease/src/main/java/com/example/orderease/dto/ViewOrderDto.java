
package com.example.orderease.dto;

import java.time.LocalDate;

public class ViewOrderDto {

    private String customerId;
    private String customerName; 
    private String mobileNumber; 
    private String address;     
    private String orderId;
    private String productId;
    private int productMrp;
    private int productcounts;
    private int sellingPrice;
    
    private String productName;
    private LocalDate orderDate;

    // Getters and setters for all fields (including the new ones)

    
    
    
    public String getCustomerId() {
        return customerId;
    }

    public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public int getProductMrp() {
        return productMrp;
    }

    public void setProductMrp(int productMrp) {
        this.productMrp = productMrp;
    }

    public int getProductcounts() {
        return productcounts;
    }

    public void setProductcounts(int productcounts) {
        this.productcounts = productcounts;
    }

    public int getSellingPrice() {
        return sellingPrice;
    }

    public void setSellingPrice(int sellingPrice) {
        this.sellingPrice = sellingPrice;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public ViewOrderDto() {
        super();
    }

	@Override
	public String toString() {
		return "ViewOrderDto [customerId=" + customerId + ", customerName=" + customerName + ", mobileNumber="
				+ mobileNumber + ", address=" + address + ", orderId=" + orderId + ", productId=" + productId
				+ ", productMrp=" + productMrp + ", productcounts=" + productcounts + ", sellingPrice=" + sellingPrice
				+ ", productName=" + productName + ", orderDate=" + orderDate + "]";
	}

   
}
