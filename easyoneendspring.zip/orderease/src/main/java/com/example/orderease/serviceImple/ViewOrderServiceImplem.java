
package com.example.orderease.serviceImple;

import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.orderease.dao.CustomerRepository; 
import com.example.orderease.dao.OrderRepository;
import com.example.orderease.dao.ProductRepository;
import com.example.orderease.dao.ViewOrderRepository;
import com.example.orderease.dto.ResponseDto;
import com.example.orderease.dto.ViewOrderDto;
import com.example.orderease.entity.CustomerEntity; 
import com.example.orderease.entity.OrderEntity;
import com.example.orderease.entity.ProductEntity;
import com.example.orderease.entity.ViewOrderEntity;
import com.example.orderease.service.ViewOrderService;

@Service
public class ViewOrderServiceImplem implements ViewOrderService {

    @Autowired
    private ViewOrderRepository viewOrderRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private CustomerRepository customerRepository; 

    @Autowired
    private ProductRepository productRepository;
    
    ResponseDto response = new ResponseDto();
    
    
    
    
    @Override
    public List<ViewOrderDto> findOrderIdProcess(String orderId) {

        List<ViewOrderEntity> viewOrderEntities = viewOrderRepository.findByOrderIdNative(orderId);
        List<ViewOrderDto> dtos = new ArrayList<>();

        try {
            
            OrderEntity orderEntity = orderRepository.findById(orderId).orElse(null);
            if (orderEntity != null) {
                String customerId = orderEntity.getCustomerId();
              
                CustomerEntity customerEntity = customerRepository.findById(customerId).orElse(null);
                
                

                String customerName = null;
                String mobileNumber = null;
                String address = null;

                if (customerEntity != null) {
                    customerName = customerEntity.getCustomerName();
                    mobileNumber = customerEntity.getMobileNumber();
                    address = customerEntity.getAddress();
                } else {
                    System.out.println("Warning: Customer details not found for customerId: " + customerId);
                }

                for (ViewOrderEntity entity : viewOrderEntities) {
                    ViewOrderDto dto = new ViewOrderDto();

                    dto.setCustomerId(entity.getCustomerId());
                    dto.setCustomerName(customerName);
                    dto.setMobileNumber(mobileNumber);
                    dto.setAddress(address);
                    dto.setProductId(entity.getProductId());
                    
                    String productName = entity.getProductId();
                    ProductEntity productEntity = productRepository.findById(productName).orElse(null);
                    
                    dto.setProductName(productEntity.getProductName());
                    
                    dto.setOrderId(entity.getOrderId());
                    dto.setProductcounts(entity.getProductCounts());
                    dto.setProductMrp(entity.getProductMrp());
                    dto.setSellingPrice(entity.getSellingPrice());
                    dto.setOrderDate(entity.getOrderDate());
                    dtos.add(dto);
                }
            } else {
              
                for (ViewOrderEntity entity : viewOrderEntities) {
                    ViewOrderDto dto = new ViewOrderDto();
                    dto.setCustomerId(entity.getCustomerId());
                    dto.setProductId(entity.getProductId());
                    dto.setOrderId(entity.getOrderId());
                    dto.setProductcounts(entity.getProductCounts());
                    dto.setProductMrp(entity.getProductMrp());
                    dto.setSellingPrice(entity.getSellingPrice());
                    dto.setOrderDate(entity.getOrderDate());
                    dtos.add(dto);
                }
                System.out.println("Warning: Order not found for orderId: " + orderId);
            }

        } catch (Exception e) {
            System.out.println("Exception in findOrderIdProcess: " + e.getMessage());
            throw e;
        }

        return dtos;
    }


    @Override
    public ResponseDto deleteOrderProcess(String customerId) {

        List<ViewOrderEntity> viewOpt = viewOrderRepository.findByCustIdNative(customerId);
        
        try {

        if (!viewOpt.isEmpty()) {

            viewOrderRepository.deleteByCustIdNative(customerId);

            List<OrderEntity> orderOpt = orderRepository.findByCustIdOrder(customerId);

            if (!orderOpt.isEmpty()) {

                orderRepository.deleteByCustIdOrder(customerId);
            }


            response.setResponseMessage("Order has been deleted successfully");
            response.setResponseStatusCode(200);


        } else {

            response.setResponseMessage("Order has been deleted successfully");
            response.setResponseStatusCode(200);

        }
        }
        
        catch(Exception e) {
        	throw e;
        }


        return response;
    }
}
