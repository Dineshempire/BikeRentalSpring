package com.example.orderease.entity;

import java.time.LocalDate;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="vieworder_tab")
public class ViewOrderEntity {
	
	@Id
	@UuidGenerator
	@Column(name="view_order_id")
	private String viewOrderId;
	
	@Column(name="order_id")
	private String orderId;
	
	@Column(name="product_id")
	private String productId;
	
	@Column(name="customer_id")
	private String customerId;
	
	@Column(name="product_counts")
	private int productCounts;
	
	@Column(name="product_mrp")
	private int productMrp;
	
	@Column(name="selling_price")
	private int sellingPrice;
	
	@CreationTimestamp
	@Column(name="order_date")
	private LocalDate orderDate;

	public String getViewOrderId() {
		return viewOrderId;
	}

	public void setViewOrderId(String viewOrderId) {
		this.viewOrderId = viewOrderId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public int getProductCounts() {
		return productCounts;
	}

	public void setProductCounts(int productCounts) {
		this.productCounts = productCounts;
	}

	public int getProductMrp() {
		return productMrp;
	}

	public void setProductMrp(int productMrp) {
		this.productMrp = productMrp;
	}

	public int getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(int sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	
	

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public ViewOrderEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ViewOrderEntity [viewOrderId=" + viewOrderId + ", orderId=" + orderId + ", productId=" + productId
				+ ", customerId=" + customerId + ", productCounts=" + productCounts + ", productMrp=" + productMrp
				+ ", sellingPrice=" + sellingPrice + ", orderDate=" + orderDate + "]";
	}

	
	
	
	

}
