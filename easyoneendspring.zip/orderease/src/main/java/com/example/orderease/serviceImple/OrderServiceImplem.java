package com.example.orderease.serviceImple;



import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.orderease.dao.CustomerRepository;
import com.example.orderease.dao.OrderRepository;
import com.example.orderease.dao.ProductRepository;
import com.example.orderease.dao.ViewOrderRepository;
import com.example.orderease.dto.CustomerDto;
import com.example.orderease.dto.OrderDto;
import com.example.orderease.dto.OrderProductDto;
import com.example.orderease.dto.OrderResponseDto;
import com.example.orderease.dto.ResponseDto;
import com.example.orderease.dto.ViewOrderDto;
import com.example.orderease.entity.CustomerEntity;
import com.example.orderease.entity.OrderEntity;
import com.example.orderease.entity.ProductEntity;
import com.example.orderease.entity.ViewOrderEntity;
import com.example.orderease.service.OrderService;

@Service
public class OrderServiceImplem implements OrderService {
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	ViewOrderRepository viewOrderRepository;
	
	

	
	
	@Override
	public ResponseDto placeOrderProcess(OrderDto dto) {
		
		ResponseDto response  = new ResponseDto();
		
		 OrderEntity order = new OrderEntity();
		 
		 ProductEntity product = new ProductEntity();
		 try {
		 
		 order.setCustomerId(dto.getCustomerId());
		 order.setOrderDate(dto.getOrderDate());
		 order.setOrderStatus(true);
		 
		 OrderEntity saveOrder = orderRepository.save(order);
		 
		
		 
		 int resultAmount = 0;
		 
		 for(OrderProductDto val : dto.getProductOrder()) {
			
			ViewOrderEntity viewOrder = new ViewOrderEntity();
			
			Optional<ProductEntity> prodOpt = productRepository.findById(val.getProductId());
			
			if(prodOpt.isPresent()) {
				
				ProductEntity prods = prodOpt.get();
			
			viewOrder.setOrderId(saveOrder.getOrderId()) ;
			
			viewOrder.setProductCounts(val.getProductCount());
			
			viewOrder.setCustomerId(dto.getCustomerId());
			
			viewOrder.setSellingPrice(prods.getProductPrice());
			
			viewOrder.setProductId(val.getProductId());
			viewOrder.setProductMrp(prods.getProductMrp());
			
			
			viewOrder.setOrderDate(dto.getOrderDate());
			
			resultAmount += (val.getProductCount()) * (prods.getProductMrp());
			System.out.println(resultAmount);
			
			
			viewOrderRepository.save(viewOrder);
			
			response.setResponseMessage("Order has been placed Successfully");
			response.setResponseStatusCode(200);
			}
			
			
			
			//viewOrder.setProductMrp(resultAmount)dto.getProductName();
			
			//viewOrderRepository.save(viewOrderEntity);
		}
		 order.setTotalAmount(resultAmount);
		 orderRepository.save(order);
		 System.out.println(resultAmount);
		 }
		 
		 catch(Exception e) {
			 response.setResponseMessage("Order was not placed");
			 response.setResponseStatusCode(400);
		 }
			
			
			
		
		
//		catch(Exception e) {
//			response.setResponseMessage("Order was not placed");
//			response.setResponseStatusCode(400);
//			throw e;
//		}
		
		return response;
		
	}
	
	
//	@Override
//	public List<OrderDto> getOrderProcess(String customerId){
//		//OrderEntity cust = new OrderEntity();
//		
//		List<OrderEntity> ordOpt = orderRepository.findByCustNameNative(customerId);
//		List<OrderDto> dtos = new ArrayList<>();
//		
//				
//		
//		for(OrderEntity entity : ordOpt) {
//			OrderDto dto = new OrderDto();
//
//			
//			dto.setOrderId(entity.getOrderId());
//			dto.setOrderDate(entity.getOrderDate());
//			dto.setTotalAmount(entity.getTotalAmount());
//			dto.setOrderStatus(entity.isOrderStatus());
//			dtos.add(dto);
//		}
//
//		
//		return dtos;
//		
//		
//	}
	
	
	@Override
	public List<OrderDto> getOrderProcess(String customerId){
	    // Get the orders by customer ID
	    List<OrderEntity> ordOpt = orderRepository.findByCustNameNative(customerId);
	    List<OrderDto> dtos = new ArrayList<>();

	    // Fetch the customer details using the customer repository
	    Optional<CustomerEntity> customerOpt = customerRepository.findById(customerId);

	    // Check if customer exists
	    if (!customerOpt.isPresent()) {
	        // Handle the case where customer is not found (you can return an error response or empty list)
	        return dtos;  // or throw an exception as needed
	    }

	    CustomerEntity customer = customerOpt.get();

	    // Loop through orders and create DTOs
	    for (OrderEntity entity : ordOpt) {
	        OrderDto dto = new OrderDto();
	        
	        // Set order details
	        dto.setOrderId(entity.getOrderId());
	        dto.setOrderDate(entity.getOrderDate());
	        dto.setTotalAmount(entity.getTotalAmount());
	        dto.setOrderStatus(entity.isOrderStatus());

	        // Set customer details in order DTO (Customer info can be set as needed)
	        dto.setCustomerName(customer.getCustomerName());
	        dto.setMobileNumber(customer.getMobileNumber());
	        dto.setAddress(customer.getAddress());
	        
	        // Add order dto to the list
	        dtos.add(dto);
	    }

	    return dtos;
	}


}
