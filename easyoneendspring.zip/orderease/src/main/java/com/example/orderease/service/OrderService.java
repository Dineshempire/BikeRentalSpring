package com.example.orderease.service;
import java.util.*;

import com.example.orderease.dto.OrderDto;
import com.example.orderease.dto.OrderResponseDto;
import com.example.orderease.dto.ResponseDto;

public interface OrderService {
	
	ResponseDto placeOrderProcess(OrderDto dto);
	List<OrderDto>getOrderProcess(String customerId);
	ResponseDto deleteOrderById(String orderId);

}
