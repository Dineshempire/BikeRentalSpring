package com.example.orderease.dto;

//public class OrderResponseDto {
//
//}




public class OrderResponseDto {

    private String responseMessage;
    private int responseStatusCode;
    private String orderId; // Add this field

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public int getResponseStatusCode() {
        return responseStatusCode;
    }

    public void setResponseStatusCode(int responseStatusCode) {
        this.responseStatusCode = responseStatusCode;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public OrderResponseDto() {
        super();
    }

    // Add a constructor that accepts orderId as well
    public OrderResponseDto(String responseMessage, int responseStatusCode, String orderId) {
        this.responseMessage = responseMessage;
        this.responseStatusCode = responseStatusCode;
        this.orderId = orderId;
    }

    @Override
    public String toString() {
        return "ResponseDto [responseMessage=" + responseMessage + ", responseStatusCode=" + responseStatusCode
                + ", orderId=" + orderId + "]";
    }
}
