package com.example.orderease.serviceImple;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.orderease.dao.ProductRepository;
import com.example.orderease.dto.ProductDto;
import com.example.orderease.dto.ResponseDto;
import com.example.orderease.entity.ProductEntity;
import com.example.orderease.service.ProductService;

@Service
public class ProductServiceImplem implements ProductService {
	
	@Autowired
	private  ProductRepository productRepository;
	


	@Override
	public ResponseDto addProductProcess(ProductDto dto) {
		ResponseDto response = new ResponseDto();
		
		try {
			ProductEntity prod = new ProductEntity(dto);
			
			productRepository.save(prod);
			response.setResponseMessage("Product saved Successfully");
			response.setResponseStatusCode(200);
			
		}catch(Exception e) {
			e.printStackTrace();
			response.setResponseMessage("Error Occurs");
			response.setResponseStatusCode(400);
		}
		
		return response;
	}
	
	
	public ResponseDto addProductProcessOld(ProductDto dto) {
	    ResponseDto response = new ResponseDto();
	    ProductEntity productEntity;

	    try {
	        if (dto.getProductId() != null) {
	            // Update Existing Product
	            Optional<ProductEntity> existingProductOpt = productRepository.findById(dto.getProductId());

	            if (existingProductOpt.isPresent()) {
	                productEntity = existingProductOpt.get();
	                productEntity.setProductName(dto.getProductName());
	                productEntity.setProductUnit(dto.getProductUnit());
	                productEntity.setProductMrp(dto.getProductMrp());
	                productEntity.setProductPrice(dto.getProductPrice());
	                productEntity.setTax(dto.getTax());

	                productRepository.save(productEntity);
	                response.setResponseMessage("Product Updated Successfully");
	                response.setResponseStatusCode(200);
	            } else {
	                response.setResponseMessage("Product Not Found");
	                response.setResponseStatusCode(404);
	            }
	        } else {
	            
	            Optional<ProductEntity> existingProduct = productRepository.findByProductName(dto.getProductName());

	            if (existingProduct.isPresent()) {
	                response.setResponseMessage("Product already exists!");
	                response.setResponseStatusCode(409); 
	                return response;
	            }

	            
	            productEntity = new ProductEntity();
	            productEntity.setProductName(dto.getProductName());
	            productEntity.setProductUnit(dto.getProductUnit());
	            productEntity.setProductMrp(dto.getProductMrp());
	            productEntity.setProductPrice(dto.getProductPrice());
	            productEntity.setTax(dto.getTax());

	            productRepository.save(productEntity);
	            response.setResponseMessage("Product has been added successfully");
	            response.setResponseStatusCode(200);
	        }
	    } catch (Exception e) {
	        response.setResponseMessage("Product could not be processed");
	        response.setResponseStatusCode(400);
	        throw e;
	    }

	    return response;
	}

	
	
	@Override
	public List<ProductDto> getProductProcess(String productId) {
		
		ProductEntity prod = new ProductEntity();
		
		Optional<ProductEntity> prodOpt = productRepository.findById(productId);
		List<ProductDto> dtos = new ArrayList<>();
		
		ProductDto dto = new ProductDto();
		
		try {

		if(!prodOpt.isEmpty()) {
			prod = prodOpt.get();
			dto.setProductName(prod.getProductName());
			dto.setProductPrice(prod.getProductPrice());
			dto.setProductUnit(prod.getProductUnit());
			//dto.setProductValue(prod.getProductValue());
			dto.setProductMrp(prod.getProductMrp());
			dto.setProductId(prod.getProductId());
		}
		dtos.add(dto);
		}
		
		catch(Exception e) {
			throw e;
		}
		
		
		
		return dtos;
		
	}
	
	@Override
    public List<ProductDto> getProductByName(String productName) {
        List<ProductEntity> productEntities = productRepository.findByProductNameIgnoreCase(productName);
        List<ProductDto> productDtos = new ArrayList<>();
        
        try {
        for (ProductEntity entity : productEntities) {
            ProductDto dto = new ProductDto();
            dto.setProductId(entity.getProductId());
            dto.setProductName(entity.getProductName());
            dto.setProductUnit(entity.getProductUnit());
            dto.setProductMrp(entity.getProductMrp());
            dto.setProductPrice(entity.getProductPrice());
           // dto.setProductValue(entity.getProductValue());
            dto.setTax(entity.getTax());
            productDtos.add(dto);
        }
        }
        
        catch(Exception e) {
        	throw e;
        }
        return productDtos;
    }
	
	
	@Override
	public ResponseDto deleteBikeById(String productId) {
	    ResponseDto response = new ResponseDto();

	    Optional<ProductEntity> bikeOpt = productRepository.findById(productId);

	    try {
	    if (bikeOpt.isPresent()) {
	        productRepository.deleteById(productId);
	        response.setResponseMessage("Product deleted successfully");
	        response.setResponseStatusCode(200);
	    } else {
	        response.setResponseMessage("Product not found");
	        response.setResponseStatusCode(404);
	    }
	    }
	    
	    catch(Exception e) {
	    	throw e;
	    }

	    return response;
	}
	
	 @Override
	    public List<ProductDto> getAllProducts() {
	        List<ProductEntity> productEntities = productRepository.findAll();
	        List<ProductDto> productDtos = new ArrayList<>();
	        
	        try {
	        for (ProductEntity entity : productEntities) {
	            ProductDto dto = new ProductDto();
	            dto.setProductId(entity.getProductId());
	            dto.setProductName(entity.getProductName());
	            dto.setProductUnit(entity.getProductUnit());
	            dto.setProductMrp(entity.getProductMrp());
	            dto.setProductPrice(entity.getProductPrice());
	            dto.setTax(entity.getTax());
	            productDtos.add(dto);
	        }
	        }
	        
	        catch(Exception e) {
	        	throw e;
	        }
	        return productDtos;
	    }
	
	
	@Override
	public ResponseDto deleteAllProduct() {
		
		ResponseDto response = new ResponseDto();
		
		List<ProductEntity> prodOpt = productRepository.findAll();
		
		if(prodOpt.contains(prodOpt)) {
			productRepository.deleteAll(prodOpt);
			response.setResponseMessage("All had been deleted successfully");
			response.setResponseStatusCode(200);
		}
		
		else {
			
			response.setResponseMessage("ProductEntity was Empty");
			response.setResponseStatusCode(400);
		}
		return response;
		
	}

}
