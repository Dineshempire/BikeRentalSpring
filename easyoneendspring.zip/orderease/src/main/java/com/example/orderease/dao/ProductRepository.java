package com.example.orderease.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.orderease.entity.ProductEntity;

@Repository
public interface ProductRepository extends JpaRepository<ProductEntity,String> {
	List<ProductEntity> findByProductNameIgnoreCase(String productName);
	
	Optional<ProductEntity> findByProductId(String productId);
	
	Optional<ProductEntity> findByProductName(String productName);


}
