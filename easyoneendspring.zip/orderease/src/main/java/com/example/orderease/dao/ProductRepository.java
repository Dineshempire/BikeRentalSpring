package com.example.orderease.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.orderease.entity.ProductEntity;

public interface ProductRepository extends JpaRepository<ProductEntity,String> {
	List<ProductEntity> findByProductNameIgnoreCase(String productName);
	

}
