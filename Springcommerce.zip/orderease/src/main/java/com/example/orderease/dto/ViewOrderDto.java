package com.example.orderease.dto;

import java.time.LocalDate;

public class ViewOrderDto {
	
	//private String viewOrderId;
	//private String orderId;
	private String customerId;
	private String productId;
	private int productMrp;
	private int productcounts;
	private int sellingPrice;
	private LocalDate orderDate;
	
	
//	public String getOrderId() {
//		return orderId;
//	}
//	public void setOrderId(String orderId) {
//		this.orderId = orderId;
//	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public int getProductcounts() {
		return productcounts;
	}
	public void setProductcounts(int productCount) {
		this.productcounts = productCount;
	}
	public int getSellingPrice() {
		return sellingPrice;
	}
	public void setSellingPrice(int sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	
	
	
	
//	public String getViewOrderId() {
//		return viewOrderId;
//	}
//	public void setViewOrderId(String viewOrderId) {
//		this.viewOrderId = viewOrderId;
//	}
	public int getProductMrp() {
		return productMrp;
	}
	public void setProductMrp(int productMrp) {
		this.productMrp = productMrp;
	}
	public LocalDate getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	public ViewOrderDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ViewOrderDto [customerId=" + customerId + ", productId=" + productId + ", productMrp=" + productMrp
				+ ", productcounts=" + productcounts + ", sellingPrice=" + sellingPrice + ", orderDate=" + orderDate
				+ "]";
	}
	
	
	
	
	
	
	

}
