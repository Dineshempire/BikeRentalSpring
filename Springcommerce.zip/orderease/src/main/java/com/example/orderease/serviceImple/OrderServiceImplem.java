package com.example.orderease.serviceImple;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.orderease.dao.CustomerRepository;
import com.example.orderease.dao.OrderRepository;
import com.example.orderease.dao.ProductRepository;
import com.example.orderease.dao.ViewOrderRepository;
import com.example.orderease.dto.OrderDto;
import com.example.orderease.dto.ResponseDto;
import com.example.orderease.entity.OrderEntity;
import com.example.orderease.entity.ProductEntity;
import com.example.orderease.entity.ViewOrderEntity;
import com.example.orderease.service.OrderService;

@Service
public class OrderServiceImplem implements OrderService {
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	ViewOrderRepository viewOrderRepository;
	
	@Override
	public ResponseDto placeOrderProcess(OrderDto dto) {
		
		ResponseDto response  = new ResponseDto();
		
		Optional<ProductEntity> prodOpt = productRepository.findById(dto.getProductId());
		
		try {
		
		if(!prodOpt.isEmpty()) {
			ProductEntity product = prodOpt.get();
			
			int count = dto.getProductCount();
			
			int price = product.getProductPrice();
			
			int taxPercent = product.getTax();
			
			int totalAmount = count*price;
			
			double taxAmount = (taxPercent/100)*totalAmount;
			
			double finalAmount  =totalAmount+taxAmount;
			
			int resultAmount = (int)finalAmount;
			
			OrderEntity order = new OrderEntity();
			
			order.setCustomerId(dto.getCustomerId());
			order.setOrderDate(dto.getOrderDate());
			order.setTotalAmount(resultAmount);
			order.setOrderStatus(true);
			
			OrderEntity saveOrder = orderRepository.save(order);
			
			response.setResponseMessage("Order has been placed successfully");
			response.setResponseStatusCode(200);
			
			
			
			
			ViewOrderEntity viewOrder = new ViewOrderEntity();
			viewOrder.setOrderId(saveOrder.getOrderId()) ;
			viewOrder.setProductCounts(dto.getProductCount());
			viewOrder.setCustomerId(dto.getCustomerId());
			
			viewOrder.setSellingPrice(product.getProductPrice());
			
			viewOrder.setProductId(dto.getProductId());
			
			viewOrder.setProductMrp(product.getProductMrp());
			
			viewOrder.setSellingPrice(product.getProductPrice());
			viewOrder.setOrderDate(dto.getOrderDate());
			
			viewOrderRepository.save(viewOrder);
			
			//viewOrder.setProductMrp(resultAmount)dto.getProductName();
			
			//viewOrderRepository.save(viewOrderEntity);
		}
			
			
			
		}
		
		catch(Exception e) {
			response.setResponseMessage("Order was not placed");
			response.setResponseStatusCode(400);
			throw e;
		}
		
		return response;
		
	}

}
