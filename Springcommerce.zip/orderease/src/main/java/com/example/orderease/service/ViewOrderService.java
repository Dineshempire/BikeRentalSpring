package com.example.orderease.service;

import java.util.List;

import com.example.orderease.dto.ResponseDto;
import com.example.orderease.dto.ViewOrderDto;

public interface ViewOrderService {
	
	List<ViewOrderDto> viewOrderProcess(String customerId);
	
	ResponseDto  deleteOrderProcess(String customerId);

}
