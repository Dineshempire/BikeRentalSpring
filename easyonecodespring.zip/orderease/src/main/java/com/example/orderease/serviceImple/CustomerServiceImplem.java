package com.example.orderease.serviceImple;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.orderease.dao.CustomerRepository;

import com.example.orderease.dto.CustomerDto;

import com.example.orderease.dto.ResponseDto;
import com.example.orderease.entity.CustomerEntity;

import com.example.orderease.service.CustomerService;

@Service
public class CustomerServiceImplem implements CustomerService{
	
	@Autowired
	private  CustomerRepository customerRepository;
	
	@Override
	public ResponseDto addCustomerProcess(CustomerDto dto) {
		
		ResponseDto response = new ResponseDto();
		CustomerEntity customerEntity = new CustomerEntity();
		
		
		try {
			
			if(dto.getCustomerId()!=null) {
				
					Optional<CustomerEntity> addOpt = customerRepository.findById(dto.getCustomerId());
				
					if(!addOpt.isEmpty()) {
						customerEntity = addOpt.get();
						
						customerEntity.setCustomerName(dto.getCustomerName());
						customerEntity.setMobileNumber(dto.getMobileNumber());
						customerEntity.setUserEmail(dto.getUserEmail());
						customerEntity.setAddress(dto.getAddress());
					}
					customerRepository.save(customerEntity);
					response.setResponseMessage("Customer Updated Successfully");
					response.setResponseStatusCode(200);
			}
			
			
			else {
			customerEntity.setCustomerName(dto.getCustomerName());
			customerEntity.setMobileNumber(dto.getMobileNumber());
			customerEntity.setUserEmail(dto.getUserEmail());
			customerEntity.setAddress(dto.getAddress());
			
			
			customerRepository.save(customerEntity);
			response.setResponseMessage("Customer has been added successfully");
			response.setResponseStatusCode(200);
			}
			
			
			
			
			
		}
		
		catch(Exception e) {
			
			response.setResponseMessage("Customer was not added ");
			response.setResponseStatusCode(400);
			throw e;
			//return response;
			
		}
		
		return response;
		
		
		
	}
	
	@Override
	public List<CustomerDto> getCustomerById(String customerId){
		
        CustomerEntity cust = new CustomerEntity();
		
		Optional<CustomerEntity> custOpt = customerRepository.findById(customerId);
		List<CustomerDto> dtos = new ArrayList<>();
		
		CustomerDto dto = new CustomerDto();

		if(!custOpt.isEmpty()) {
			cust = custOpt.get();
			dto.setCustomerName(cust.getCustomerName());
			dto.setUserEmail(cust.getUserEmail());
			dto.setMobileNumber(cust.getMobileNumber());
			dto.setAddress(cust.getAddress());
			
		}
		dtos.add(dto);
		return dtos;
		
	}
	
	public ResponseDto deleteCustomerById(String customerId) {
		ResponseDto response = new ResponseDto();
		Optional<CustomerEntity> custOpt= customerRepository.findById(customerId);
		
		 if (custOpt.isPresent()) {
		        customerRepository.deleteById(customerId);
		        response.setResponseMessage("Bike deleted successfully");
		        response.setResponseStatusCode(200);
		    } else {
		        response.setResponseMessage("Bike not found");
		        response.setResponseStatusCode(404);
		    }
		
		
		return response ;
	}
	

}
