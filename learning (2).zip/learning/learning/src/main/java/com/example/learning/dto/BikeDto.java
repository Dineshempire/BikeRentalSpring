package com.example.learning.dto;

public class BikeDto {
	
	private String bikeId;
	private String bikeNumber;
	private String rcBook;
	private String startTime;
	private String endTime;
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	private String insuranceNumber;
	private String casesOrFines;
	private String availableLocation;
	private int ratingInfo;
	
	
	public String getBikeId() {
		return bikeId;
	}
	public void setBikeId(String bikeId) {
		this.bikeId = bikeId;
	}
	public String getBikeNumber() {
		return bikeNumber;
	}
	public void setBikeNumber(String bikeNumber) {
		this.bikeNumber = bikeNumber;
	}
	public String getRcBook() {
		return rcBook;
	}
	public void setRcBook(String rcBook) {
		this.rcBook = rcBook;
	}
	public String getInsuranceNumber() {
		return insuranceNumber;
	}
	public void setInsuranceNumber(String insuranceNumber) {
		this.insuranceNumber = insuranceNumber;
	}
	public String getCasesOrFines() {
		return casesOrFines;
	}
	public void setCasesOrFines(String casesOrFines) {
		this.casesOrFines = casesOrFines;
	}
	public String getAvailableLocation() {
		return availableLocation;
	}
	public void setAvailableLocation(String availableLocation) {
		this.availableLocation = availableLocation;
	}
	public int getRatingInfo() {
		return ratingInfo;
	}
	public void setRatingInfo(int ratingInfo) {
		this.ratingInfo = ratingInfo;
	}
	@Override
	public String toString() {
		return "BikeDto [bikeId=" + bikeId + ", bikeNumber=" + bikeNumber + ", rcBook=" + rcBook + ", insuranceNumber="
				+ insuranceNumber + ", casesOrFines=" + casesOrFines + ", availableLocation=" + availableLocation
				+ ", ratingInfo=" + ratingInfo + "]";
	}
	public BikeDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
