package com.example.learning.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.learning.dto.ResponseDto;
import com.example.learning.service.AddBikeService;
import com.example.learning.dto.BikeDto;

@RestController
@RequestMapping("api")
public class AddBikeController {
	
	@Autowired
	AddBikeService addBikeService;
	
	@PostMapping("/add")
	
	public ResponseEntity<ResponseDto> addBikeDetails(@RequestBody BikeDto dto) {
		return ResponseEntity.ok(addBikeService.addBikeDetails(dto));
		
	}
	
	@GetMapping("/issues/{availableLocation}")
	public ResponseEntity<BikeDto> getBikeByLocation(@PathVariable("availableLocation") String availableLocation) {
		return ResponseEntity.ok(addBikeService.getBikeByLocation(availableLocation));
	}

}
