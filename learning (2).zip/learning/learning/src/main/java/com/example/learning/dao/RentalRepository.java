package com.example.learning.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.learning.entity.AddEntity;

public interface RentalRepository extends JpaRepository<AddEntity, String>  {

}
