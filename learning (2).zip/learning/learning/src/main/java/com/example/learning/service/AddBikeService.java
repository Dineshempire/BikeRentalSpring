package com.example.learning.service;

import com.example.learning.dto.BikeDto;
import com.example.learning.dto.ResponseDto;

public interface AddBikeService {
	
	ResponseDto addBikeDetails(BikeDto dto);
	
	BikeDto getBikeByLocation(String availableLocation);

}
