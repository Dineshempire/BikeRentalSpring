package com.example.learning.serviceImplem;
import java.util.*;

import com.example.learning.dto.ResponseDto;
import com.example.learning.entity.AddEntity;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.learning.dao.RentalRepository;
import com.example.learning.dto.BikeDto;
import com.example.learning.service.AddBikeService;


@Service
public class AddBikeServiceImplem implements AddBikeService {
	
	@Autowired
	private RentalRepository rentalRepository;
	
	@Override
	public ResponseDto addBikeDetails(BikeDto dto) {
		
		ResponseDto response = new ResponseDto();
		
		try {
			
			AddEntity addBike = new AddEntity();
			
			if(dto.getBikeId() != null) {
				Optional<AddEntity> addOpt = rentalRepository.findById(dto.getBikeId());
				
				if(!addOpt.isEmpty()) {
					addBike = addOpt.get();
					addBike.setBikeNumber(dto.getBikeNumber());
					addBike.setCasesOrFines(dto.getCasesOrFines());
					addBike.setInsuranceNumber(dto.getInsuranceNumber());
					addBike.setRatingInfo(dto.getRatingInfo());
					addBike.setRcBook(dto.getRcBook());
					addBike.setStartTime(dto.getStartTime());
					addBike.setEndTime(dto.getEndTime());
				}
				
				
			}
			else {
				addBike.setBikeNumber(dto.getBikeNumber());
				addBike.setInsuranceNumber(dto.getInsuranceNumber());
				addBike.setRatingInfo(dto.getRatingInfo());
				addBike.setRcBook(dto.getRcBook());
				addBike.setAvailableLocation(dto.getAvailableLocation());
				addBike.setCasesOrFines(dto.getCasesOrFines());	
				addBike.setStartTime(dto.getStartTime());
				addBike.setEndTime(dto.getEndTime());
				rentalRepository.save(addBike);
				
				System.out.println(dto.getBikeNumber());
				}
			
			//rentalRepository.save(addBike);
			response.setMessage("Bike Added Successfully");
			response.setStatusCode(200);
			
			
		}
		
		catch(Exception e) {
			response.setMessage("FAILURE");
			response.setStatusCode(400);
			throw e;
			
		}
		
		return response;
		
	}
	
//	@Override
//	public BikeDto getBikeByLocation(String availableLocation) {
//		
//		BikeDto dto = new BikeDto();
//		Optional<AddEntity> addOpt = rentalRepository.findById(availableLocation);
//		
//		if (!addOpt.isEmpty()) {
//
//			AddEntity addEntity=addOpt.get();
//			dto.setBikeId(addEntity.getBikeId());
//			dto.setBikeNumber(addEntity.getBikeNumber());
//			dto.setCasesOrFines(addEntity.getCasesOrFines());
//			dto.setInsuranceNumber(addEntity.getInsuranceNumber());
//			dto.setRatingInfo(addEntity.getRatingInfo());
//			dto.setStartTime(addEntity.getStartTime());
//			dto.setEndTime(addEntity.getEndTime());
//			dto.setRcBook(addEntity.getRcBook());
//			
//			
//			
//		}
//		return dto;
//		
//	}
	
	
	@Override
	public List<BikeDto> getAvailableBikesByLocationAndTime(String location) {
	    List<AddEntity> bikes = rentalRepository.getAvailableBikesByLocationAndTime(location);
	    List<BikeDto> dtos = new ArrayList<>();

	    for (AddEntity bike : bikes) {
	        BikeDto dto = new BikeDto();
	        dto.setBikeId(bike.getBikeId());
	        dto.setBikeNumber(bike.getBikeNumber());
	        dto.setRcBook(bike.getRcBook());
	        dto.setInsuranceNumber(bike.getInsuranceNumber());
	        dto.setCasesOrFines(bike.getCasesOrFines());
	        dto.setAvailableLocation(bike.getAvailableLocation());
	        dto.setRatingInfo(bike.getRatingInfo());
	        dto.setStartTime(bike.getStartTime());
	        dto.setEndTime(bike.getEndTime());

	        dtos.add(dto);
	    }

	    return dtos;
	}
	
	
	@Override
	public ResponseDto deleteBikeById(String bikeId) {
	    ResponseDto response = new ResponseDto();

	    Optional<AddEntity> bikeOpt = rentalRepository.findById(bikeId);

	    if (bikeOpt.isPresent()) {
	        rentalRepository.deleteById(bikeId);
	        response.setMessage("Bike deleted successfully");
	        response.setStatusCode(200);
	    } else {
	        response.setMessage("Bike not found");
	        response.setStatusCode(404);
	    }

	    return response;
	}

}
