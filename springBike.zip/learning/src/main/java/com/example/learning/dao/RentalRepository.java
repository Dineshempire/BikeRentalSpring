package com.example.learning.dao;
import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.learning.entity.AddEntity;

public interface RentalRepository extends JpaRepository<AddEntity, String>  {
	
	 @Query(nativeQuery = true,value = "SELECT * FROM add_bikes WHERE available_location = :location")
	 List<AddEntity> getAvailableBikesByLocationAndTime(@Param("location") String location);
	 
	 @Query(nativeQuery = true,value = "SELECT * FROM add_bikes WHERE available_location = :location AND start_time = :startTime AND end_time = :endTime AND rating_info = :ratingInfo")
	 List<AddEntity> rentBikeDetails(@Param("location") String location, @Param("startTime") String startTime, @Param("endTime") String endTime, @Param("ratingInfo") String ratingInfo);

}
