package com.example.learning.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.learning.entity.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, String> {

	//void save(UserEntity userEntity);
	

}
