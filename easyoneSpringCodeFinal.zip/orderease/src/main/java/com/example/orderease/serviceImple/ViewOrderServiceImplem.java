package com.example.orderease.serviceImple;
import java.util.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.orderease.dao.OrderRepository;
import com.example.orderease.dao.ViewOrderRepository;
import com.example.orderease.dto.ResponseDto;
import com.example.orderease.dto.ViewOrderDto;
import com.example.orderease.entity.OrderEntity;
import com.example.orderease.entity.ViewOrderEntity;
import com.example.orderease.service.ViewOrderService;


@Service
public class ViewOrderServiceImplem implements ViewOrderService {
	
	@Autowired
	private ViewOrderRepository viewOrderRepository;	
	@Autowired
	private OrderRepository orderRepository;
	
	ResponseDto response = new ResponseDto();
	
	@Override
	public List<ViewOrderDto> findOrderIdProcess(String orderId)
	{
		
		ViewOrderEntity view = new ViewOrderEntity();
		
		
		List<ViewOrderEntity> viewOpt = viewOrderRepository.findByOrderIdNative(orderId);
		
		List<ViewOrderDto> dtos = new ArrayList<>();
		
		
		
		
		try {
		for(ViewOrderEntity entity : viewOpt) {
			ViewOrderDto dto = new ViewOrderDto();
			
			dto.setCustomerId(entity.getCustomerId());
			dto.setProductId(entity.getProductId());
			dto.setOrderId(entity.getOrderId());
			dto.setProductcounts(entity.getProductCounts());
			dto.setProductMrp(entity.getProductMrp());
			dto.setSellingPrice(entity.getSellingPrice());
			dto.setOrderDate(entity.getOrderDate());
			dtos.add(dto);
		}
		
		}
		
		catch(Exception e) {
			System.out.println("Exception");
			throw e;
		}
		
	
		return dtos;
		
		
	}
	
	
	@Override
	public ResponseDto deleteOrderProcess(String customerId) {
		
		List<ViewOrderEntity> viewOpt = viewOrderRepository.findByCustIdNative(customerId);
		
		if(!viewOpt.isEmpty()) {
			
			 viewOrderRepository.deleteByCustIdNative(customerId);
			 
			 List<OrderEntity> orderOpt = orderRepository.findByCustIdOrder(customerId);
			 
			 if(!orderOpt.isEmpty()) {
				 
				 orderRepository.deleteByCustIdOrder(customerId);
			 }
			 
			 
			 response.setResponseMessage("Order has been deleted successfully");
			 response.setResponseStatusCode(200);
			
			
		}
		
		else {
			
			response.setResponseMessage("Order has been deleted successfully");
			 response.setResponseStatusCode(200);
			
		}
		
		
		 
		 
		
		return response;
		
	}

}
