package com.example.orderease.controller;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.orderease.dto.OrderDto;
import com.example.orderease.dto.ResponseDto;
import com.example.orderease.service.OrderService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("orderapi")
public class OrderController {
	
	@Autowired
	private OrderService orderService;
	
	@PostMapping("/postorder")
	public ResponseEntity<ResponseDto> placeOrderProcess(@RequestBody OrderDto dto){
		return ResponseEntity.ok(orderService.placeOrderProcess(dto));
		
	}
	
	@GetMapping("/getorder")
	
	public ResponseEntity<List<OrderDto>> getOrderProcess(@RequestParam("customerId") String customerId ){
		return ResponseEntity.ok(orderService.getOrderProcess(customerId));
		
	}
	

}
