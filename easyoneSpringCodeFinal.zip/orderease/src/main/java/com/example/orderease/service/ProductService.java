package com.example.orderease.service;
import java.util.*;

import com.example.orderease.dto.ProductDto;
import com.example.orderease.dto.ResponseDto;

public interface ProductService {
	
	ResponseDto  addProductProcess(ProductDto dto);
	
	List<ProductDto> getProductProcess(String productId);
	
	ResponseDto deleteBikeById(String productId);
	
	ResponseDto deleteAllProduct();
	
	List<ProductDto> getProductByName(String productName); 

}
