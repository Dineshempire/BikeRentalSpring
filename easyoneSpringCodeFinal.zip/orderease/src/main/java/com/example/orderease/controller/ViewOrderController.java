package com.example.orderease.controller;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.orderease.dto.ResponseDto;
import com.example.orderease.dto.ViewOrderDto;
import com.example.orderease.service.ViewOrderService;

@RestController
@RequestMapping("apiview")
public class ViewOrderController {
	
	
	@Autowired
	private ViewOrderService viewOrderService;
	
	
	@GetMapping("/vieworder")
	
	public ResponseEntity<List<ViewOrderDto>> findOrderIdProcess(@RequestParam("orderId") String orderId){
		return ResponseEntity.ok(viewOrderService.findOrderIdProcess(orderId));
		
	}
	
	
	@DeleteMapping("/deleteorder")
	
	public ResponseEntity<ResponseDto> deleteOrderProcess(@RequestParam("customerId") String customerId){
		return ResponseEntity.ok(viewOrderService.deleteOrderProcess(customerId));
		
	}
	

}
