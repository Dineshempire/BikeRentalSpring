package com.example.orderease.dto;
import java.util.*;

import java.time.LocalDate;

public class OrderDto { 
	
	private String orderId;
	private String customerId;
	
	private List<OrderProductDto> productOrder;

	private LocalDate orderDate;
	
	private int totalAmount;
	
	private boolean orderStatus;
	
	
	
	
	public boolean isOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(boolean orderStatus) {
		this.orderStatus = orderStatus;
	}
	public int getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	
	
	public List<OrderProductDto> getProductOrder() {
		return productOrder;
	}
	public void setProductOrder(List<OrderProductDto> productOrder) {
		this.productOrder = productOrder;
	}
	public OrderDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "OrderDto [orderId=" + orderId + ", customerId=" + customerId + ", productOrder=" + productOrder
				+ ", orderDate=" + orderDate + ", totalAmount=" + totalAmount + ", orderStatus=" + orderStatus + "]";
	}
	
	
	
	
	

	
	
	
	
	

}
