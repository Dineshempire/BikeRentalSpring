package com.example.orderease.dto;

public class OrderProductDto {
	
	private String productId;
	
	private int productCount;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public int getProductCount() {
		return productCount;
	}

	public void setProductCount(int productCount) {
		this.productCount = productCount;
	}

	public OrderProductDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "OrderProductDto [productId=" + productId + ", productCount=" + productCount + "]";
	}
	
	

}
