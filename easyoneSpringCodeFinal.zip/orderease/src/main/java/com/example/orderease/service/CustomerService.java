package com.example.orderease.service;
import java.util.*;

import com.example.orderease.dto.CustomerDto;
import com.example.orderease.dto.ResponseDto;

public interface CustomerService {
	
	ResponseDto addCustomerProcess(CustomerDto dto);
	
	List<CustomerDto> getCustomerById(String customerId);
	
	ResponseDto deleteCustomerById(String customerId);
	
	ResponseDto deleteAllCustomer();
	
	List<CustomerDto> getAllCustomers();
	

}
