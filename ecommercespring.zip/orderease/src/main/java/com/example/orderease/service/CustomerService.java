package com.example.orderease.service;

import com.example.orderease.dto.CustomerDto;
import com.example.orderease.dto.ResponseDto;

public interface CustomerService {
	
	ResponseDto addCustomerProcess(CustomerDto dto);

}
