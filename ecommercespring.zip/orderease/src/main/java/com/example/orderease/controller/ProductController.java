package com.example.orderease.controller;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.orderease.dto.ProductDto;
import com.example.orderease.dto.ResponseDto;
import com.example.orderease.service.ProductService;

@RestController
@RequestMapping("product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@PostMapping("/addproduct")
	
	public ResponseEntity<ResponseDto> addProductProcess(@RequestBody ProductDto dto){
		return ResponseEntity.ok(productService.addProductProcess(dto));
		//return null;
		
	}
	
	@GetMapping("/getproduct")
	
	public ResponseEntity<List<ProductDto>> getProductProcess(@RequestParam("productId") String productId){
		return ResponseEntity.ok(productService.getProductProcess(productId));
		
	}
	
	@DeleteMapping("/deleteproduct")
	public ResponseEntity<ResponseDto> deleteBikeById(@RequestParam("productId") String productId) {
	    return ResponseEntity.ok(productService.deleteBikeById(productId));
	}
	

}
