package com.example.orderease.dto;

public class ResponseDto {
	
	private String responseMessage;
	private int responseStatusCode;
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public int getResponseStatusCode() {
		return responseStatusCode;
	}
	public void setResponseStatusCode(int responseStatusCode) {
		this.responseStatusCode = responseStatusCode;
	}
	public ResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ResponseDto [responseMessage=" + responseMessage + ", responseStatusCode=" + responseStatusCode + "]";
	}
	
	

}
