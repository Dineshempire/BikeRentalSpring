package com.example.orderease.serviceImple;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.orderease.dao.CustomerRepository;

import com.example.orderease.dto.CustomerDto;

import com.example.orderease.dto.ResponseDto;
import com.example.orderease.entity.CustomerEntity;

import com.example.orderease.service.CustomerService;

@Service
public class CustomerServiceImplem implements CustomerService{
	
	@Autowired
	private  CustomerRepository customerRepository;
	
	@Override
	public ResponseDto addCustomerProcess(CustomerDto dto) {
		
		ResponseDto response = new ResponseDto();
		CustomerEntity customerEntity = new CustomerEntity();
		
		
		try {
			
			if(dto.getCustomerId()!=null) {
				
					Optional<CustomerEntity> addOpt = customerRepository.findById(dto.getCustomerId());
				
					if(!addOpt.isEmpty()) {
						customerEntity = addOpt.get();
						
						customerEntity.setCustomerName(dto.getCustomerName());
						customerEntity.setMobileNumber(dto.getMobileNumber());
						customerEntity.setUserEmail(dto.getUserEmail());
						customerEntity.setAddress(dto.getAddress());
					}
					customerRepository.save(customerEntity);
					response.setResponseMessage("Customer Updated Successfully");
					response.setResponseStatusCode(200);
			}
			
			
			else {
			customerEntity.setCustomerName(dto.getCustomerName());
			customerEntity.setMobileNumber(dto.getMobileNumber());
			customerEntity.setUserEmail(dto.getUserEmail());
			customerEntity.setAddress(dto.getAddress());
			
			
			customerRepository.save(customerEntity);
			response.setResponseMessage("Customer has been added successfully");
			response.setResponseStatusCode(200);
			}
			
			
			
			
			
		}
		
		catch(Exception e) {
			
			response.setResponseMessage("Customer was not added ");
			response.setResponseStatusCode(400);
			throw e;
			//return response;
			
		}
		
		return response;
		
		
		
	}
	

}
