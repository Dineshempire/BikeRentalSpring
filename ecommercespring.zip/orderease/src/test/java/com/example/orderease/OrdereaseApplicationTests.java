package com.example.orderease;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdereaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
