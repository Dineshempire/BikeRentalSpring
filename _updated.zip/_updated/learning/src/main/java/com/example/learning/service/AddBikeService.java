package com.example.learning.service;
import java.util.*;

import com.example.learning.dto.BikeDto;
import com.example.learning.dto.ResponseDto;

public interface AddBikeService {
	
	ResponseDto addBikeDetails(BikeDto dto);
	
	BikeDto getBikeByLocation(String availableLocation);
	
	List<BikeDto> getAvailableBikesByLocationAndTime(String location,String dropOffTime);
	
	ResponseDto deleteBikeById(String bikeId);


}
