package com.example.orderease.entity;


import java.time.LocalDate;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="orders")
public class OrderEntity {
	
	@Id
	@UuidGenerator
	@Column(name="order_id")
	private String orderId;
	
	@Column(name="customer_id")
	private String customerId;
	
	@Column(name="total_amount")
	private int totalAmount;
	
	@Column(name="order_date")
	private LocalDate orderDate;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}

	public OrderEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "OrderEntity [orderId=" + orderId + ", customerId=" + customerId + ", totalAmount=" + totalAmount
				+ ", orderDate=" + orderDate + "]";
	}

	
	

}
