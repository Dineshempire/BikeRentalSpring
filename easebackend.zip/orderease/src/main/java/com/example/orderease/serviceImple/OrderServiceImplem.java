package com.example.orderease.serviceImple;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.orderease.dao.CustomerRepository;
import com.example.orderease.dao.OrderRepository;
import com.example.orderease.dao.ProductRepository;
import com.example.orderease.dto.OrderDto;
import com.example.orderease.dto.ResponseDto;
import com.example.orderease.entity.OrderEntity;
import com.example.orderease.entity.ProductEntity;
import com.example.orderease.entity.ViewOrderEntity;

public class OrderServiceImplem {
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	OrderRepository orderRepository;
	
	public ResponseDto placeOrderProcess(OrderDto dto) {
		
		Optional<ProductEntity> prodOpt = productRepository.findById(dto.getProductId());
		
		if(!prodOpt.isEmpty()) {
			ProductEntity product = prodOpt.get();
			
			int count = dto.getProductCount();
			
			int price = product.getProductPrice();
			
			int taxPercent = product.getTax();
			
			int totalAmount = count*price;
			
			double taxAmount = (taxPercent/100)*totalAmount;
			
			double finalAmount  =totalAmount+taxAmount;
			
			int resultAmount = (int)finalAmount;
			
			OrderEntity order = new OrderEntity();
			
			order.setCustomerId(dto.getCustomerId());
			order.setOrderDate(dto.getOrderDate());
			order.setTotalAmount(resultAmount);
			
			OrderEntity saveOrder = orderRepository.save(order);
			
			
			ViewOrderEntity viewOrder = new ViewOrderEntity();
			viewOrder.setOrderId(saveOrder.getOrderId()) ;
			viewOrder.setProductCounts(dto.getProductCount());
			
			viewOrder.setSellingPrice(product.getProductPrice());
			
			dto.getProductId();
			//viewOrder.setProductMrp(resultAmount)dto.getProductName();
			
			//viewOrderRepository.save(viewOrderEntity);
			
			
			
		}
		
		return null;
		
	}

}
