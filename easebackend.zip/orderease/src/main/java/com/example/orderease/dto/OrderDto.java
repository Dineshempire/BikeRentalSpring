package com.example.orderease.dto;

import java.time.LocalDate;

public class OrderDto { 
	
	private String customerId;
	private String productId;
	
	private int productCount;
	private LocalDate orderDate;
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public int getProductCount() {
		return productCount;
	}
	public void setProductCount(int productCount) {
		this.productCount = productCount;
	}
	public LocalDate getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	public OrderDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "OrderDto [customerId=" + customerId + ", productId=" + productId + ", productCount=" + productCount
				+ ", orderDate=" + orderDate + "]";
	}
	
	

}
