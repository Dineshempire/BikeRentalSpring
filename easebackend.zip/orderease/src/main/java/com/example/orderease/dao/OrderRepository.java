package com.example.orderease.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.orderease.entity.OrderEntity;

public interface OrderRepository extends JpaRepository<OrderEntity,String> {

}
