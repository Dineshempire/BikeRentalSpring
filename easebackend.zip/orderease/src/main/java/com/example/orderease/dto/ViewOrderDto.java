package com.example.orderease.dto;

public class ViewOrderDto {
	
	private String orderId;
	private String customerId;
	private String productId;
	private String productcounts;
	private String totalAmount;
	
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductcounts() {
		return productcounts;
	}
	public void setProductcounts(String productcounts) {
		this.productcounts = productcounts;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public ViewOrderDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ViewOrderDto [orderId=" + orderId + ", customerId=" + customerId + ", productId=" + productId
				+ ", productcounts=" + productcounts + ", totalAmount=" + totalAmount + "]";
	}
	
	

}
