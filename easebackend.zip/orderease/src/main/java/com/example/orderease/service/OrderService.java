package com.example.orderease.service;

import com.example.orderease.dto.OrderDto;
import com.example.orderease.dto.ResponseDto;

public interface OrderService {
	
	ResponseDto placeOrderProcess(OrderDto dto);

}
