package com.example.orderease.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="product")
public class ProductEntity {
	
	@Id
	@UuidGenerator
	@Column(name="product_id")
	private String productId;
	
	@Column(name="product_name")
	private String productName;
	
	@Column(name="product_unit")
	private int productUnit;
	
	
	

	@Column(name="product_mrp")
	private int productMrp;
	
	@Column(name="product_price")
	private int productPrice;
	

	@Column(name="tax")
	private int tax;
	
	public int getTax() {
		return tax;
	}

	public void setTax(int tax) {
		this.tax = tax;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductUnit() {
		return productUnit;
	}

	public void setProductUnit(int productUnit) {
		this.productUnit = productUnit;
	}

	public int getProductMrp() {
		return productMrp;
	}

	public void setProductMrp(int productMrp) {
		this.productMrp = productMrp;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	@Override
	public String toString() {
		return "ProductEntity [productId=" + productId + ", productName=" + productName + ", productUnit=" + productUnit
				+ ", productMrp=" + productMrp + ", productPrice=" + productPrice + ", tax=" + tax + "]";
	}

	
	

	
	
	
	

}
