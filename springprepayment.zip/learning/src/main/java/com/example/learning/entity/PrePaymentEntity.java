package com.example.learning.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "payments")
public class PrePaymentEntity {
    
    @Id
    @UuidGenerator
    @Column(name="payment_id")
    private String paymentId;
    
    @Override
	public String toString() {
		return "PrePaymentEntity [paymentId=" + paymentId + ", userEmail=" + userEmail + ", bikeId=" + bikeId
				+ ", basePrice=" + basePrice + ", discount=" + discount + ", finalAmount=" + finalAmount + ", status="
				+ status + "]";
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getBikeId() {
		return bikeId;
	}

	public void setBikeId(String bikeId) {
		this.bikeId = bikeId;
	}

	public double getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getFinalAmount() {
		return finalAmount;
	}

	public void setFinalAmount(double finalAmount) {
		this.finalAmount = finalAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name="user_email")
    private String userEmail;
    
    @Column(name="bike_id")
    private String bikeId;
    
    @Column(name="base_price")
    private double basePrice;
    
    @Column(name="discount")
    private double discount;
    
    @Column(name="final_amount")
    private double finalAmount;
    
    @Column(name="status")
    private String status; 
    
    
}
