package com.example.learning.service;

import com.example.learning.dto.ResponseDto;
import com.example.learning.dto.UserDto;

public interface UserAuthService {
	
	ResponseDto userAuthProcess(UserDto dto);

}
