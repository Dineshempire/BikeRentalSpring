package com.example.learning.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.learning.dto.BikeDto;
import com.example.learning.dto.ResponseDto;
import com.example.learning.entity.PrePaymentEntity;




@RestController
@RequestMapping("paymentapi")
public class PrePaymentController {

//    @Autowired
//    private PaymentService paymentService;
//
//    @PostMapping("/calculate")
//    public ResponseEntity<PrePaymentEntity> calculatePayment(@RequestBody PrePaymentDto prePayment) {
//        BikeDto bike = prePayment.getBike();
//        String start = prePayment.getStartTime();
//        String end = prePayment.getEndTime();
//        String userEmail = prePayment.getUserEmail();
//
//        PrePaymentEntity payment = prePayment.calculatePayment(bike, start, end, userEmail);
//        return ResponseEntity.ok(payment);
//    }
    
    @Autowired
    private PaymentService paymentService;

    @PostMapping("/calculate")
    public ResponseEntity<ResponseDto> calculatePayment(
            @RequestParam String bikeId,
            @RequestParam String startTime,
            @RequestParam String endTime,
            @RequestParam String userEmail
    ) {
        ResponseDto response = paymentService.calculatePayment(bikeId, startTime, endTime, userEmail);
        return ResponseEntity.ok(response);
    }
}

