package com.example.learning.service;

import java.util.List;

import com.example.learning.dto.BikeDto;

public interface RentBikeService {
	
	List<BikeDto> rentBikeDetails(String location,String startTime,String endTime,String ratingInfo);

}
