package com.example.learning.serviceImplem;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.learning.dao.RentalRepository;
import com.example.learning.dto.BikeDto;
import com.example.learning.entity.AddEntity;
import com.example.learning.service.RentBikeService;

@Service
public class RentBikeServiceImplem implements RentBikeService {
	
	@Autowired
	private RentalRepository rentalRepository;
	
	@Override
	public List<BikeDto> rentBikeDetails(String location, String startTime, String endTime, String ratingInfo){
		
		 List<AddEntity> bikes = rentalRepository.rentBikeDetails(location,startTime,endTime,ratingInfo);
		 List<BikeDto> dtos = new ArrayList<>();
		 
		 for (AddEntity bike : bikes) {
		        BikeDto dto = new BikeDto();
		        dto.setBikeId(bike.getBikeId());
		        dto.setBikeNumber(bike.getBikeNumber());
		        dto.setRcBook(bike.getRcBook());
		        dto.setInsuranceNumber(bike.getInsuranceNumber());
		        dto.setCasesOrFines(bike.getCasesOrFines());
		        dto.setAvailableLocation(bike.getAvailableLocation());
		        dto.setRatingInfo(bike.getRatingInfo());
		        dto.setStartTime(bike.getStartTime());
		        dto.setEndTime(bike.getEndTime());

		        dtos.add(dto);
		    }
		
		
		return dtos;
		
	}

}
