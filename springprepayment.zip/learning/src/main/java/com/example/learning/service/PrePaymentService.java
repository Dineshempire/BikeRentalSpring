package com.example.learning.service;

import com.example.learning.dto.ResponseDto;

public interface PrePaymentService {
	
	ResponseDto calculatePayment(String bikeId, String startTime, String endTime, String userEmail);

}
