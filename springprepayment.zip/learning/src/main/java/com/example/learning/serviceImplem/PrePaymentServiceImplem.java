package com.example.learning.serviceImplem;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.learning.dao.PrePaymentRepository;
import com.example.learning.dao.RentalRepository;
import com.example.learning.dto.ResponseDto;
import com.example.learning.entity.AddEntity;
import com.example.learning.entity.PrePaymentEntity;
import com.example.learning.service.PrePaymentService;



@Service
public class PrePaymentServiceImplem implements PrePaymentService {

    @Autowired
    private PrePaymentRepository paymentRepository;

    @Autowired
    private RentalRepository rentalRepository;

    @Override
    public ResponseDto calculatePayment(String bikeId, String startTime, String endTime, String userEmail) {
        ResponseDto response = new ResponseDto();

        Optional<AddEntity> bikeOpt = rentalRepository.findById(bikeId);
        if (bikeOpt.isEmpty()) {
            response.setMessage("Bike not found");
            response.setStatusCode(404);
            return response;
        }

        AddEntity bike = bikeOpt.get();
        int basePrice = 50 * bike.getRatingInfo(); // base = rating * 50
        int hours = Math.abs(Integer.parseInt(endTime)-Integer.parseInt(startTime));
        
        int finalAmount = basePrice * hours;
        double discount = 0;

        if (hours > 5) {
            discount = 0.10 * finalAmount;
            finalAmount -= discount;
        }

        PrePaymentEntity payment = new PrePaymentEntity();
        payment.setBikeId(bikeId);
        payment.setBasePrice(basePrice);
        payment.setDiscount(discount);
        payment.setFinalAmount(finalAmount);
        payment.setUserEmail(userEmail);
        payment.setStatus("PENDING");

        paymentRepository.save(payment);

        response.setMessage("Payment calculated successfully. Final amount: ₹" + finalAmount);
        response.setStatusCode(200);
        return response;
    }

    
}

