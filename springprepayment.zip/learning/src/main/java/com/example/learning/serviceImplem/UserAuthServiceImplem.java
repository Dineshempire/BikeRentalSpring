package com.example.learning.serviceImplem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.learning.dao.UserRepository;
import com.example.learning.dto.ResponseDto;
import com.example.learning.dto.UserDto;
import com.example.learning.entity.UserEntity;
import com.example.learning.service.UserAuthService;

@Service
public class UserAuthServiceImplem implements UserAuthService {
	
	@Autowired
	UserRepository userRepository;
	public ResponseDto userAuthProcess(UserDto dto) {
		
		ResponseDto response = new ResponseDto();
		
		try {
			
			
			UserEntity userEntity = new UserEntity();
			
			userEntity.setUserName(dto.getUserName());
			userEntity.setPhoneNumber(dto.getPhoneNumber());
			userEntity.setUserEmail(dto.getUserEmail());
			userEntity.setPassWord(dto.getPassWord());
			userEntity.setDepositAmount(dto.getDepositAmount());
			
			userRepository.save(userEntity);
			response.setMessage("Login Successfully");
			response.setStatusCode(200);
		}
		
		catch(Exception e) {
			response.setMessage("Login Failed");
			response.setStatusCode(400);
			
		}
		
		return response;
		
		
	}

}
