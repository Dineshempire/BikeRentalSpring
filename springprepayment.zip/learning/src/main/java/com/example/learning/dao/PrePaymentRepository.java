package com.example.learning.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.learning.entity.PrePaymentEntity;

public interface PrePaymentRepository extends JpaRepository<PrePaymentEntity, String> {

}
