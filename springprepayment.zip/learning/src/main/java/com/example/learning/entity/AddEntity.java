package com.example.learning.entity;



import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "add_bikes")
public class AddEntity {
	
	@Id
	@Column(name = "bike_id")
	@UuidGenerator
	private String bikeId;
	
	@Column(name = "bike_number")
	private String bikeNumber;
	
	
	
	@Column(name = "insurance_number")
	private String insuranceNumber;
	
	
	
	@Column(name = " available_location")
	private String availableLocation;
	
	
	
	@Column(name="start_time")
	private String startTime;
	
	@Column(name="end_time")
	private String endTime;
	
	@Column(name="rc_book")
	private String rcBook;
	
	@Column(name = "cases_or_fines")
	private String casesOrFines;
	
	@Column(name ="rating_info")
	private int ratingInfo;

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getCasesOrFines() {
		return casesOrFines;
	}

	public void setCasesOrFines(String casesOrFines) {
		this.casesOrFines = casesOrFines;
	}

	public String getBikeId() {
		return bikeId;
	}

	public void setBikeId(String bikeId) {
		this.bikeId = bikeId;
	}

	public String getBikeNumber() {
		return bikeNumber;
	}

	public void setBikeNumber(String bikeNumber) {
		this.bikeNumber = bikeNumber;
	}

	public String getRcBook() {
		return rcBook;
	}

	public void setRcBook(String rcBook) {
		this.rcBook = rcBook;
	}

	public String getInsuranceNumber() {
		return insuranceNumber;
	}

	public void setInsuranceNumber(String insuranceNumber) {
		this.insuranceNumber = insuranceNumber;
	}

	

	public String getAvailableLocation() {
		return availableLocation;
	}

	public void setAvailableLocation(String availableLocation) {
		this.availableLocation = availableLocation;
	}

	public int getRatingInfo() {
		return ratingInfo;
	}

	public void setRatingInfo(int ratingInfo) {
		this.ratingInfo = ratingInfo;
	}
}
