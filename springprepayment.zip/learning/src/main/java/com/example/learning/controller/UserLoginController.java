package com.example.learning.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.learning.dto.ResponseDto;
import com.example.learning.dto.UserDto;
import com.example.learning.service.UserAuthService;

@RestController
@RequestMapping("api2")
public class UserLoginController {
	
	@Autowired
	UserAuthService userAuthService;
	
	@PostMapping("/login")
	
	public ResponseEntity<ResponseDto> userAuthProcess(@RequestBody UserDto dto){
		return ResponseEntity.ok(userAuthService.userAuthProcess(dto));
	}
	
	
	

}
