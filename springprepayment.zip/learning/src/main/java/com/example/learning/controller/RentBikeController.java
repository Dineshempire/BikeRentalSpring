package com.example.learning.controller;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.learning.dto.BikeDto;
import com.example.learning.service.RentBikeService;

@RestController
@RequestMapping("api1")
public class RentBikeController {
	
	@Autowired
	RentBikeService rentBikeService;
	
	
	@GetMapping("/rent")
	
	public ResponseEntity<List<BikeDto>> rentBikeDetails(@RequestParam("location") String location, @RequestParam("startTime") String startTime,
			@RequestParam("endTime") String endTime,@RequestParam("ratingInfo") String ratingInfo) {
				return ResponseEntity.ok(rentBikeService.rentBikeDetails(location, startTime, endTime, ratingInfo));
		
	}

}
